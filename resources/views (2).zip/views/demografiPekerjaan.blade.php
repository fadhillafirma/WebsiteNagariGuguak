<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Demografi Pekerjaan</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/bar.js"></script>
     <link rel="icon" type="image/png" href="/logo.png" />


</head>
<body>

<section class="pt-24 pb-16 px-4">
    <div class="max-w-4xl mx-auto bg-white shadow-md rounded-xl p-6">
        <h1 class="text-3xl font-bold text-greenDark text-center underline underline-offset-4 mb-2 mt-10 title-animate">
            Data Demografi Pekerjaan
        </h1>
        <p class="text-center text-gray-600 text-sm mb-8">
            Tahun: <strong>{{ $tahunTerbaru ?? '-' }}</strong>
        </p>

        <p class="text-gray-700 text-justify mb-6">
            Data demografi pekerjaan di Nagari Guguak pada tahun 2026 memberikan gambaran tentang ragam mata pencaharian masyarakat. Informasi ini mencerminkan peran berbagai sektor, mulai dari pertanian, pemerintahan, hingga profesi lainnya, dalam mendukung kehidupan ekonomi di nagari.
        </p>

        <div class="overflow-x-auto">
            <table class="w-full text-sm text-gray-700 border border-gray-200 rounded-lg">
                <thead class="bg-greenDark text-white text-sm">
                    <tr>
                        <th class="px-6 py-3 text-center">Pekerjaan</th>
                        <th class="px-6 py-3 text-center">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    @if ($data)
                        <tr class="border-t hover:bg-gray-50 ">
                            <td class="px-6 py-3 text-center">Petani</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->petani }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-6 py-3 text-center">Pegawai Negeri</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->pegawai_negeri }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-6 py-3 text-center">Karyawan Swasta</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->karyawan_swasta }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-6 py-3 text-center">Pedagang</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->pedagang }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-6 py-3 text-center">TNI</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->tni }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-6 py-3 text-center">Pensiunan</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->pensiunan }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-6 py-3 text-center">Aparat Pemerintahan</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->aparat_pemerintahan }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-6 py-3 text-center">Pekerjaan Lain</td>
                            <td class="px-6 py-3 font-semibold text-center">{{ $data->pekerjaan_lain }}</td>
                        </tr>
                        <tr class="border-t hover:bg-gray-100 font-bold bg-gray-100">
                            <td class="px-6 py-3 text-center">Total</td>
                            <td class="px-6 py-3 text-center">{{ $data->total }}</td>
                        </tr>
                    @else
                        <tr>
                            <td colspan="2" class="px-6 py-6 text-center text-gray-500">Data tidak ditemukan.</td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>

        @if ($data)
        <div class="mt-10">
            <h2 class="text-xl font-bold text-center mb-4 text-greenDark">Peringkat Profesi Berdasarkan Jumlah</h2>
            <div id="pekerjaanBarChart" style="height: 500px; width: 100%;"></div>
        </div>
        @endif

    </div>
</section>

 <section class="bg-white pt-5 pb-5 bottom-0 left-0 w-full shadow-md ">
                    <div class="max-w-6xl mx-auto text-center  justify-content-center">
                        <p>2025 Nagari Guguak.</p>
                            <p>Powered by KKN Guguak Unand 2025.</p>
                    </div>
        </section>

@include('layout.navbar')

@if ($data)
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const dataPekerjaan = [
            { name: 'Petani', y: {{ $data->petani }} },
            { name: 'Pegawai Negeri', y: {{ $data->pegawai_negeri }} },
            { name: 'Karyawan Swasta', y: {{ $data->karyawan_swasta }} },
            { name: 'Pedagang', y: {{ $data->pedagang }} },
            { name: 'TNI', y: {{ $data->tni }} },
            { name: 'Pensiunan', y: {{ $data->pensiunan }} },
            { name: 'Aparat Pemerintahan', y: {{ $data->aparat_pemerintahan }} },
            { name: 'Pekerjaan Lain', y: {{ $data->pekerjaan_lain }} }
        ];

        dataPekerjaan.sort((a, b) => b.y - a.y);

        Highcharts.chart('pekerjaanBarChart', {
            chart: { type: 'bar' },
            title: { text: null },
            xAxis: {
                categories: dataPekerjaan.map(item => item.name),
                title: { text: null }
            },
            yAxis: {
                min: 0,
                title: { text: 'Jumlah Orang', align: 'high' },
                labels: { overflow: 'justify' }
            },
            tooltip: { valueSuffix: ' orang' },
            plotOptions: {
                bar: {
                    dataLabels: { enabled: true },
                    colorByPoint: true,
                    colors: ['#004225', '#015b34', '#027a46', '#029656', '#02b869', '#38b48e', '#64c9a4', '#9ae5c0']
                }
            },
            credits: { enabled: false },
            series: [{ name: 'Jumlah', data: dataPekerjaan }]
        });
    });
            //animasi css judul title-animate
        document.addEventListener("DOMContentLoaded", function () {
        const observer = new IntersectionObserver(
            (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                entry.target.classList.add("show");
                } else {
                entry.target.classList.remove("show");
                }
            });
            },
            { threshold: 0.3 }
        );

        document.querySelectorAll(".title-animate").forEach((title) => {
            observer.observe(title);
        });
        });
</script>
@endif

</body>
</html>
